package hw1;

public class WirelessPrinter {

/**
 * PAGES_PER_CARTRIDGE is a constant variable which holds 
 * how many paper can be printed per one cartridge.
 */
public static final int PAGES_PER_CARTRIDGE = 1000;

/**
 * TRAY_CAPACITY is a constant variable that holds the maximum
 *  number of pages that can go inside of the tray.
 */
public static final int TRAY_CAPACITY = 500;

/**
 * NEW_CARTRIDGE_INK_LEVEL is a constant variable that holds
 *  maximum amount of ink in the cartridge.
 */
public static final double NEW_CARTRIDGE_INK_LEVEL = 1.0;

/**
 * Variable holds the amount of ink left in the cartridge
 */
private double cartridge;

/**
 * Variable that holds amount of paper in the Tray
 */
private int paper = 0;

/**
 * Variable that holds on/off status of the printer 
 * 0 = Off 
 * 1 = On
 */
private int power = 0;

/**
 * Variable that holds connected or disconnected status of the printer 
 * 0 = Off
 * 1 = On 
 */
private int wifi = 0;

/**
 * Variable that holds count of how many pages are printed 
 */
private int printed_pages = 0;

/**
 * Variable that holds count of how many pages are blank 
 */
private int blank_pages = 0;
/**
 * Constant variable that holds the percentage of ink each paper uses when being printed 
 */
private double  ink_perPage = 0.001;

/**
 * Create a new printer. The printer initially has a cartridge that is half full and no paper.
 */
public WirelessPrinter()
{
 cartridge = 0.5;
 paper = 0;
}

/**
 * Create a new printer with a specified amount of ink and paper.
 * @param ink
 * @param paper
 */
public WirelessPrinter(double ink, int paper)
{
 if ((ink <= NEW_CARTRIDGE_INK_LEVEL) && (ink >= 0.0))
 {
  cartridge = ink;
 }
 if ((paper <= TRAY_CAPACITY) && (paper >= 0))
 {
 this.paper = paper;
 }
}

/**
 * When the cartridge is replaced the level of ink
 *is rest to maximum or to NEW_CARTRIDGE_INK_LEVEL.
 */
public void replaceCartridge()
{
 cartridge = NEW_CARTRIDGE_INK_LEVEL;
}

/**
 * Total paper in the printer tray will be never above the capacity.
 * @param pages
 */
public void loadPaper(int pages)
{
 paper = paper + pages;

 if (paper >= TRAY_CAPACITY)
 {
  paper = 500;
 }
}

/**
 * This method simulates printing certain number of pages. If there is no enough paper left in the tray,
 *  the printing will stop once the paper runs out, and the remaining job (if any) is cancelled.
 *  If ink runs out during the printing, the printing will NOT Stop,
 *  but only blank pages are printed
 * @param pages
 */
public void print(int pages)
{
 double inkNeeded = pages *  ink_perPage;
 
 if ((wifi == 1) && (power == 1)) // Checking if it's on and connected 
 {
  if ((paper >= pages) && (cartridge >= inkNeeded))// Checking if it's has paper and ink

  {
   printed_pages = printed_pages + pages;
   paper = paper - pages;
   cartridge = cartridge - inkNeeded;
  }
  
  else if((paper < pages) && (cartridge >= inkNeeded))// if there there is not enough paper but enough ink 

  {
   printed_pages = printed_pages + paper;
   cartridge = cartridge - inkNeeded;
   paper = 0;
  }
  
   else if((paper >= pages) && (cartridge < inkNeeded))// if there is not enough ink but enough paper

  {
   int inkPages = (int) Math.round(cartridge/  ink_perPage);
   printed_pages = printed_pages + inkPages;
   int leftoverPages = pages - inkPages;
   blank_pages = blank_pages + leftoverPages;
   cartridge = 0;
   paper = paper - pages;
  } 
  
   else if ((paper < pages) && (cartridge < inkNeeded))// if both are not enough
  {
   int inkPages = (int) Math.round(cartridge/ ink_perPage);
   printed_pages = printed_pages + inkPages;
   int leftoverPages = pages - inkPages;
   blank_pages = blank_pages + leftoverPages;
   cartridge = 0;
   paper = 0;
  }
 }
}
/**
 * Returns the current ink level as a double value that is between 0.0 and 1.0.
 * @return
 */
public double getInkLevel()
{
 return cartridge;
}

/**
 * Returns how much paper, in percentage, is left, rounded to the nearest percentage.
 * @return
 */
public int getPaperLevel()
{
 int percentage = Math.round((paper /TRAY_CAPACITY) * 100);
 return percentage;
}

/**
 * Returns the exact count of the sheets of paper left in the Tray of the printer.
 * @return
 */
public int getPaperLevelExact()
{
 return paper;
}

/**
 * Returns the total number of pages printed with full ink 
 * It does not include the count of blank pages.
 * @return
 */
public int getTotalPagesPrinted()
{
 return printed_pages;
}

/**
 * Returns the total number of pages of papers used.
 * @return
 */
public int getTotalPaperUsed()
{
 return (printed_pages + blank_pages);
}

/**
 * Returns the status of current wireless connection.
 * @return
 */
public boolean isConnected()
{
 if (wifi == 1)
 {
  return true;
  
 }
 else
 {
  return false;
 }
}

/**
 * Returns the power status of the printer
 * @return
 */
public boolean isOn()
{
 if (power == 1)
 {
  return true;
 }
 else
 {
  return false;
 }
}


/**
 * Connects the printer to the network.
 */
public void connect()
{
 wifi = 1;
}

/**
 * disconnect the wireless connection.
 */
public void disconnect()
{
 wifi = 0;
}
/**
 * Turns on the printer and immediately connect it to the network.
 */

public void turnOn()
{
 power = 1;
 wifi = 1;
}
/**
 * Disconnects the wireless connection and then turns off the printer 
 */
public void turnOff()
{
 power = 0;
 wifi = 0;
}
}

