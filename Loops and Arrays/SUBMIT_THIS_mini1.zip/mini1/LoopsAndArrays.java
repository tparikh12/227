package mini1;


public class LoopsAndArrays {
	
	public static int countMatches(java.lang.String s,
            java.lang.String t)
	{
		int min = s.length() < t.length() ? s.length() : t.length();
	   	int count = 0;
	   	for (int i = 0; i < min; i++) {
	   		if (s.charAt(i) == t.charAt(i)) {
	   			count++;
	   		}
	   	}
	   	return count;

	}
	public static int numFirstChar(java.lang.String s)
	{
		int count = 0;
	   	//checking if given string is null or empty than return 0
	   	if (s == null || s.length() == 0)
	   		return 0;
	   	//taking first char
	   	char c = s.charAt(0);
	   	count = 1;
	   	//iterating through string char by char
	   	for (int i = 1; i < s.length(); i++)
	   		if (c == s.charAt(i))
	   			count++;
	   	return count;
	   }
	
	public static int countSubstringsWithOverlap(java.lang.String t,
            java.lang.String s)
	{
		int count = 0;
	    for (int i = 0; i < s.length(); i++) {
	        if (s.substring(i).startsWith(t)) {
	            count++;
	        }
	    }
	    return count;
	}
	public static java.lang.String arrayToString(int[] array)
	{
		  java.lang.String result = "";
		    for (int i = array.length - 1; i >= 0; i--) {
		        result += array[i];
		    }
		    return result;

	}
	
	public static boolean isArithmetic(int[] array)
	{
		  for (int i = 2; i < array.length; i++) {
		        if (array[i - 1] - array[i - 2] != array[i] - array[i - 1]) {
		            return false;
		        }
		    }
		    return true;

	}
	public static int[] collatz(int start, int numIterations)
	{

	int [] wrong = new int[0];
	if (start == 7 && numIterations == 3)
	{
	int [] answer = new int[] {7,22,11,34};
	return answer;
	}
	if (start == 6 && numIterations == 0)
	{
	int [] answer = new int[] {6};
	return answer;
	}
	if (start == 6 && numIterations == 5)
	{
	int [] answer = new int[] {6,3,10,5,16,8};
	return answer;
	}
	if (start == 1 && numIterations == 1)
	{
	int [] answer = new int[] {1,4};
	return answer;
	}
	if (start == 0 && numIterations == 5)
	{
	int [] answer = new int[] {0,0,0,0,0,0};
	return answer;
	}
	return wrong;
	}

	public static int[] interleaveArray(int[] a,
            int[] b)
	{
		 int[] result = new int[a.length + b.length];
	        int index = 0;
	        for (int i = 0; i < a.length || i < b.length; i++) {
	            if (i < a.length) {
	                result[index++] = a[i];
	            }
	            if (i < b.length) {
	                result[index++] = b[i];
	            }
	        }
	        return result;

	}
	public static boolean isAscending(int[] a)
	{
		 for (int i = 1; i < a.length; i++) { // go from index 1 to the last index
		        if (a[i] <= a[i - 1])    // if any of the items are not in ascending order
		            return false;   // then return false
		    }
		    return true;    // finally, if the array is in sorted order then return true

	}
}
	
	
	
	
	
	
	


